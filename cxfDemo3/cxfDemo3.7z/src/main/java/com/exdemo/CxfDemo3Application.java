package com.exdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import cxf.com.codenotfound.endpoint.HelloWorldImplService;
import cxf.com.codenotfound.types.helloworld.Person;

@SpringBootApplication
public class CxfDemo3Application {

	public static void main(String[] args) {
		SpringApplication.run(CxfDemo3Application.class, args);
	}

	public static void callWs() {
		Person persona = new Person();
		persona.setFirstName("Mike");
		persona.setLastName("Rdz");
		
		HelloWorldImplService greet = new HelloWorldImplService();
		String result = greet.getHelloWorldImplPort().sayHello(persona).getGreeting();
		System.out.println(result);
			
    }
}
