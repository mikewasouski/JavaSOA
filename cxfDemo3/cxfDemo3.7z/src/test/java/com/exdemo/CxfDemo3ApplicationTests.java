package com.exdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CxfDemo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
